# Proyecto resuelto con interfaz según los bocetos

- **Dos pantallas**: `INGRESO DE DATOS` y `GESTIONAR INCIDENTES`, accesibles con los botones de arriba.
- **Aspecto**: fondo blanco, bordes negros, etiquetas grandes, controles Swing comunes.
- **Capacidad**: 10 incidentes.
- **Prioridad**: 1 es más urgente que 2; se respeta orden de llegada en empates.
- **Funciones**: REGISTRAR, SIGUIENTE (consulta sin retirar), ATENDER (retira y marca atendido), LISTAR (muestra pendientes ordenados).

## Ejecutar con IntelliJ IDEA

1. Abrir la carpeta que contiene `pom.xml` como proyecto Maven.
2. Seleccionar JDK 17 o superior.
3. Abrir `src/main/java/ec/edu/taller/InterfazIncidentes.java`.
4. Ejecutar el método `main` (triángulo verde).

## Ejecutar con terminal

```bash
mvn compile exec:java
mvn test
```

Para ejecutar el JAR entregado, estando en la carpeta que contiene el archivo:

```bash
java -jar GestorIncidentes_Interfaz_Dibujos.jar
```

## Instrucciones para construirla por tu cuenta

Lee `GUIA_PASO_A_PASO.md`, incluido en este ZIP. Incluye pasos detallados, cómo conectar botones y una demostración para la defensa.

Esta interfaz está escrita con Java Swing a mano; **no requiere** GUI Designer ni archivos `.form`.
