# GUÍA PASO A PASO: interfaz gráfica sencilla con Java Swing

Esta guía reproduce los **dos bocetos**: (1) **INGRESO DE DATOS / NUEVO INCIDENTE**, (2) **GESTIONAR INCIDENTES**.

## 0. Qué se entrega

- `src/main/java/ec/edu/taller/IncidenteSeguridad.java`: almacena código, tipo, descripción, prioridad y estado.
- `src/main/java/ec/edu/taller/GestorIncidentes.java`: controla una `PriorityQueue` de capacidad máxima 10 desde la interfaz.
- `src/main/java/ec/edu/taller/InterfazIncidentes.java`: **interfaz hecha a mano en Swing**, sin `.form` ni diseñador visual.
- `src/test/java/ec/edu/taller/`: pruebas de los 7 métodos del gestor.
- `GestorIncidentes_Interfaz_Dibujos.jar`: ejecutable incluido en el ZIP (o disponible por separado).

## 1. Abre el proyecto

1. Descomprime el ZIP.
2. Abre IntelliJ IDEA y elige **Open** (Abrir).
3. Selecciona la carpeta `progresoUA202620-main` (la que contiene `pom.xml`).
4. Espera a que IntelliJ reconozca el proyecto Maven.
5. Asegúrate de que **Project SDK** sea JDK 17 o superior (**File > Project Structure > Project**).

## 2. Encuentra las clases

En el panel **Project**, abre:

`src > main > java > ec > edu > taller`.

Encontrarás:

- `IncidenteSeguridad.java`
- `GestorIncidentes.java`
- `InterfazIncidentes.java`

**No necesitas modificar las dos primeras.** La interfaz se construye en `InterfazIncidentes.java`.

## 3. Si quieres construirla tú paso a paso

Si ya has abierto la solución, `InterfazIncidentes.java` contiene todos los pasos, separados por comentarios `PASO 1`, `PASO 2`, etc. Puedes estudiar cada método o construirlo en una copia del proyecto.

**Paso 1. Ventana y navegación:**
- Crea `public class InterfazIncidentes extends JFrame`.
- Añade un constructor que llame a `setSize(850, 590)`, `setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)` y `setLocationRelativeTo(null)`.
- En `crearVentana()`, coloca un `JPanel` principal con `BorderLayout`.
- En `BorderLayout.NORTH`, añade una fila `GridLayout(1, 2)` con botones `INGRESO DE DATOS` y `GESTIONAR INCIDENTES`.
- Usa `CardLayout` para cambiar entre las dos pantallas.

**Paso 2. INGRESO DE DATOS:**
- En `crearPaginaIngreso()`, crea un panel con borde negro de 2 px.
- Arriba añade un `JLabel` centrado con el texto `NUEVO INCIDENTE`.
- En el centro usa `GridBagLayout` y cuatro filas:
  - `JLabel("CÓDIGO")` + `JTextField`
  - `JLabel("TIPO")` + `JComboBox<String>`
  - `JLabel("DESCRIPCIÓN")` + `JTextArea` dentro de `JScrollPane`
  - `JLabel("PRIORIDAD")` + `JSpinner` entre 1 y 10
- Abajo escribe `ESTADO INICIAL: PENDIENTE` y coloca el botón `REGISTRAR`.

**Paso 3. GESTIONAR INCIDENTES:**
- En `crearPaginaGestion()`, prepara otro `JPanel` con borde negro.
- Arriba muestra un `JLabel` con `PENDIENTES`, `DISPONIBLES` y `CAPACIDAD: 10`.
- Debajo añade los datos del siguiente incidente en dos columnas:
  - Izquierda: `CÓDIGO`, `TIPO`, `PRIORIDAD`.
  - Derecha: `ESTADO`, `DESCRIPCIÓN`.
- Añade tres botones en una fila con `GridLayout(1,3)`: `SIGUIENTE`, `ATENDER`, `LISTAR`.
- Abajo pon el título `LISTA DE INCIDENTES ORDENADOS POR PRIORIDAD`, la aclaración `MENOR VALOR = MAYOR PRIORIDAD` y un `JTextArea` no editable dentro de `JScrollPane`.

**Paso 4. Programar REGISTRAR:**
- Lee el texto con `campoCodigo.getText().trim()` y la prioridad con `(Integer) campoPrioridad.getValue()`.
- Crea `new IncidenteSeguridad(codigo, tipo, descripcion, prioridad)`.
- Llama a `gestor.registrarIncidente(nuevo)` y muestra éxito o aviso según el booleano.

**Paso 5. Programar SIGUIENTE y ATENDER:**
- **SIGUIENTE:** `gestor.consultarSiguienteIncidente()` usa `peek()` y **no elimina**.
- **ATENDER:** `gestor.atenderSiguienteIncidente()` usa `poll()`, lo elimina y cambia a `ATENDIDO`.
- Refresca las etiquetas del contador y del próximo incidente.

**Paso 6. Programar LISTAR:**
- Llama a `gestor.listarIncidentes()`, que devuelve una copia ordenada.
- Recorre esa lista con `for (IncidenteSeguridad incidente : lista)` y escribe cada fila en el `JTextArea`.
- Recuerda: la prioridad más importante es el número **más pequeño**.

**Paso 7. Conectar los botones:**
- Cada botón tiene su `addActionListener(...)`. Ejemplo:

```java
registrar.addActionListener(e -> registrarIncidente());
siguiente.addActionListener(e -> consultarSiguiente());
atender.addActionListener(e -> atenderSiguiente());
listar.addActionListener(e -> listarPendientes());
```

**Paso 8. Ejecutar:**
- Abre `InterfazIncidentes.java`.
- Presiona el triángulo verde junto a `public static void main(String[] args)`.
- Selecciona **Run 'InterfazIncidentes.main()'**.
- Si no aparece el triángulo: clic derecho sobre el archivo > **Run 'InterfazIncidentes.main()'**.
- Si ejecutas desde una terminal con Maven: `mvn compile exec:java`.
- También puedes ejecutar el JAR: `java -jar GestorIncidentes_Interfaz_Dibujos.jar` (con Java 17+).

## 4. Qué probar frente al profesor

1. En INGRESO DE DATOS registra: `INC-001`, `MALWARE`, `Virus`, prioridad **3**.
2. Registra: `INC-002`, `PHISHING`, `Correo sospechoso`, prioridad **1**.
3. Registra: `INC-003`, `FUGA_DATOS`, `Filtración`, prioridad **2**.
4. Pulsa **GESTIONAR INCIDENTES**.
5. Debe aparecer: **PENDIENTES: 3**, **DISPONIBLES: 7**, **CAPACIDAD: 10**.
6. **SIGUIENTE** muestra `INC-002` de prioridad 1 sin eliminarlo.
7. **LISTAR** muestra `INC-002`, `INC-003`, `INC-001`, en ese orden.
8. **ATENDER** extrae `INC-002`; quedan **2 pendientes y 8 espacios**.

## 5. Preguntas frecuentes de defensa

- **¿Por qué `JFrame`?** Es la ventana principal.
- **¿Por qué `JPanel`?** Para agrupar los controles.
- **¿Por qué `GridBagLayout`?** Para alinear las etiquetas y sus campos.
- **¿Por qué `CardLayout`?** Para cambiar entre INGRESO DE DATOS y GESTIONAR INCIDENTES sin abrir dos ventanas.
- **¿Qué hace `addActionListener`?** Ejecuta el método cuando se pulsa un botón.
- **¿Qué estructura usa el gestor?** `PriorityQueue`, con desempate según el orden de llegada.
- **¿Qué diferencia existe entre `peek()` y `poll()`?** Consultar sin eliminar versus extraer y eliminar.
- **¿Cómo se mantienen los contadores?** Se consultan `contarIncidentesPendientes()` y `consultarEspaciosDisponibles()`.
- **¿Se guardan los datos al cerrar?** No. Esta versión los conserva solamente mientras se ejecuta el programa.

## 6. Importante

El programa está implementado **escribiendo Java Swing a mano**, no con el GUI Designer de IntelliJ y no necesita archivos `.form`.

No es suficiente mostrar las capturas: debes ejecutar la clase Java para demostrar los botones.

Para ejecutar las pruebas originales con Maven: `mvn test`.
